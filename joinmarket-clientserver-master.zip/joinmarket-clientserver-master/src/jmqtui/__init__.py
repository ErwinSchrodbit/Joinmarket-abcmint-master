from .open_wallet_dialog import (
    Ui_OpenWalletDialog)
