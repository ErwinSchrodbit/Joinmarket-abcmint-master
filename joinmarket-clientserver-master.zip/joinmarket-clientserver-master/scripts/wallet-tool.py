#!/usr/bin/env python3
from jmbase import jmprint
from jmclient import wallet_tool_main

if __name__ == "__main__":
    jmprint(wallet_tool_main("wallets"), "success")
