Joinmarket-clientserver 0.6.3:
=================

<https://github.com/joinmarket-org/joinmarket-clientserver/releases/tag/v0.6.3>

THIS RELEASE WAS DEPRECATED IN FAVOUR OF 

<https://github.com/joinmarket-org/joinmarket-clientserver/releases/tag/v0.6.3.1>

The release notes for 0.6.3.1 can be found [here](release-notes-0.6.3.1.md).